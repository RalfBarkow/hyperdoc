(asdf:defsystem "shop3-planning-domains"
  :description "SHOP3 domain and reading material for Zettel 11667"
  :version "0.4.0"
  :depends-on ("dreyeck/shop3")
  :components
  ((:module "src"
    :components ((:file "zettel-11667-shop3")))
   (:module "pages"
    :components ((:static-file "SHOP3 Planning Domains.html")
                 (:static-file "Zettel 11667 Work Plan.html")
                 (:static-file "PR 41 Source Review.html")))
   (:module "topics"
    :components ((:static-file "shop3-planning-domains.md")
                 (:static-file "shop3-planning-domains.html")
                 (:static-file "shop3-planning-domains.dita")
                 (:static-file "zettel-11667-review-41.md")
                 (:static-file "topic-authoring-and-storage.md")
                 (:static-file "localhost-first-publication.md")))
   (:module "data"
    :components ((:static-file "fedwiki-page.json")
                 (:static-file "schema.sql")
                 (:static-file "seed.sql")))
   (:static-file "README.md"))
  :in-order-to ((asdf:test-op (asdf:test-op "shop3-planning-domains/tests"))))

(asdf:defsystem "shop3-planning-domains/presentation"
  :description "Optional HyperDoc presentation for the page attachment"
  :depends-on ("shop3-planning-domains" "hyperdoc")
  :components ((:file "hyperdoc")))

(asdf:defsystem "shop3-planning-domains/tests"
  :depends-on ("shop3-planning-domains")
  :components ((:file "tests"))
  :perform (asdf:test-op (operation component)
             (declare (ignore operation component))
             (uiop:symbol-call "DREYECK/WORK/ZETTEL-11667/TESTS" "RUN-TESTS")))

(asdf:defsystem "shop3-planning-domains/publication"
  :description "Localhost-first SHOP3 plan for publishing FedWiki pages and attachments"
  :depends-on ("dreyeck/shop3")
  :components ((:file "src/publication"))
  :in-order-to ((asdf:test-op (asdf:test-op "shop3-planning-domains/publication/tests"))))

(asdf:defsystem "shop3-planning-domains/publication/tests"
  :depends-on ("shop3-planning-domains/publication")
  :components ((:file "publication-tests"))
  :perform (asdf:test-op (operation component)
             (declare (ignore operation component))
             (uiop:symbol-call "SHOP3-PLANNING-DOMAINS/PUBLICATION/TESTS" "RUN-TESTS")))
