(in-package #:dreyeck/work/zettel-11667)

(hyperdoc:defhyperdoc *planning-domains-hyperdoc*
  :id "shop3-planning-domains"
  :title "SHOP3 Planning Domains"
  :asdf-system-name "shop3-planning-domains"
  :subdirectory "pages"
  :code-subdirectory "src"
  :main-page-id "SHOP3 Planning Domains")
