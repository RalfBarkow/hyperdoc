;;;; Localhost-first publication planning for page and attachment releases.
;;;; Load dreyeck/shop3 before loading this file. Only plan and inspect here.
(defpackage #:shop3-planning-domains/publication
  (:use #:cl)
  (:export #:plan-next #:step-brief))
(in-package #:shop3-planning-domains/publication)

(defparameter *stages*
  '((:observe-local nil
     "Read the local page JSON and determine the server's actual site root."
     "HTTP status and JSON identity; for a persisted page also pathname and SHA-256.")
    (:create-local (:local-page-missing)
     "Create the missing localhost page using the existing page JSON fixture."
     "Persisted page readback at the expected slug.")
    (:fill-local (:local-page-present)
     "Add missing Markdown and Assets items in the local original editor. Retain existing item IDs and the journal."
     "The edited page rereads with the Concept and assets reference under the same slug.")
    (:attach-local (:local-page-present :local-content-verified)
     "Attach the reviewed ZIP and verify its digest in the local Wiki."
     "Asset bytes match the release; page and archive remain available after reload.")
    (:verify-zip-discovery (:local-page-present :local-attachment-verified)
     "Run the existing Zettel 11687 ZIP acceptance task against this page asset."
     "Archive identity, exact ASD member, discovery observation and Workspace offer in the local Catalog.")
    (:prepare-release (:local-page-present :local-content-verified :local-attachment-verified :local-zip-discovery-verified)
     "Prepare a public page snapshot and an exact asset manifest from the checked localhost version."
     "Reviewable public page JSON and asset paths and hashes; private journal and work state stay local.")
    (:observe-target (:release-reviewed)
     "Check the actual production Wiki origin, existing page, assets and the Catalog's discovery contract."
     "Explicit target path and observed status, including any conflicts.")
    (:reconcile-target (:release-reviewed :target-conflict)
     "Compare the existing destination with the reviewed release and decide how to update it."
     "Revision-bound update decision or documented deferral.")
    (:publish-assets (:release-reviewed :target-ready)
     "Operator publishes the approved asset files for the release."
     "Expected paths and matching digests from the destination.")
    (:publish-page (:release-reviewed :target-ready :public-assets-verified)
     "Operator publishes the reviewed page JSON to the destination Wiki."
     "Destination reread of the reviewed story and Assets item.")
    (:verify-publication (:public-assets-verified :public-page-verified)
     "Open the public Wiki page and the HyperDoc view; verify the asset and Workspace offer."
     "Public page, ZIP digest, and offer for the actual Catalog revision.")))

(defparameter *mech-stages*
  '((:observe-local nil
     "Locate the persisted Mech of Mastodon page on the MacBook and read its JSON."
     "Record the actual local site root, slug, page SHA-256 and Assets reference.")
    (:create-local (:local-page-missing)
     "Recover or persist the intended Mech of Mastodon version under its local slug."
     "Persisted page readback at pages/mech-of-mastodon.")
    (:fill-local (:local-page-present)
     "Verify the saved Mech, Code and Assets items against the selected release."
     "Readback of the three items, their IDs and the publishable journal.")
    (:verify-local-browser-assets (:local-page-present :local-content-verified
                                    :local-attachment-verified)
     "Check archive members and run the inline Mech click path in the local Catalog."
     "ZIP SHA-256, exact ASD member, and local Story, host response and Mech Preview observations.")
    (:prepare-release (:local-page-present :local-content-verified
                       :local-attachment-verified :local-browser-assets-verified)
     "Review the page JSON and ZIP as one Mech release."
     "Manifest with the two release hashes, destination paths and a publishable journal.")
    (:publish-assets (:release-reviewed :target-ready)
     "Stage the reviewed ZIP from the MacBook, then install and reread it in the Catalog's site root."
     "Destination ZIP path and SHA-256 match the reviewed manifest.")
    (:publish-page (:release-reviewed :target-ready :public-assets-verified)
     "Stage the reviewed FedWiki JSON from the MacBook and install it under its extensionless slug."
     "Destination JSON path, SHA-256 and unchanged Assets item.")
    (:verify-publication (:public-assets-verified :public-page-verified)
     "Open the public HyperDoc view and verify the stored Mech Story."
     "The Catalog shows Story at /view/mech-of-mastodon and retains the reviewed items.")
    (:observe-catalog-revision (:public-view-verified)
     "Check whether the running Catalog contains the page-attached Mech asset route."
     "Running Catalog revision containing 96e19220 and the expected host HTML response.")
    (:verify-browser-preview (:public-view-verified :catalog-revision-verified)
     "Click Play in the public Story and record the inline Mech Preview."
     "Page-attached browser assets, live journa.host request after Play and inline preview.")))

(defun publication-stages (profile &optional source-origin)
  (let ((stages
          (ecase profile
            (:shop3-planning-domains *stages*)
            (:mech-of-mastodon
             (append
              (loop for stage in *stages*
                    for id = (first stage)
                    collect (if (eq id :verify-zip-discovery)
                                (assoc :verify-local-browser-assets *mech-stages*)
                                (or (assoc id *mech-stages*) stage)))
              (remove-if-not (lambda (stage)
                               (member (first stage) '(:observe-catalog-revision :verify-browser-preview)))
                             *mech-stages*))))))
    (if source-origin
        (list* '(:resolve-local-site-root nil
                 "Read the running Wiki's configuration and resolve its effective site root for the source origin."
                 "Listener or launcher, configuration source, absolute site root and page backend.")
               '(:observe-local (:local-site-root-observed)
                 "Check the slug's JSON response and its persisted state in the resolved site store."
                 "HTTP result and persisted page identity, or corroborated absence in that store.")
               (rest stages))
        stages)))

(defparameter *evidence-keys*
  '(:local-page-missing :local-page-present :local-content-verified
    :local-attachment-verified :local-zip-discovery-verified :release-reviewed :target-conflict
    :target-ready :public-assets-verified :public-page-verified
    :local-browser-assets-verified :public-view-verified :catalog-revision-verified
    :public-browser-preview-verified :local-site-root-observed
    :local-lineup-page-visible :local-lineup-not-found))

(defun step-brief (step &key (profile :shop3-planning-domains) source-origin)
  (destructuring-bind (id requires task evidence)
      (or (assoc step (publication-stages profile source-origin)) (error "Unknown publication step ~S." step))
    (list :step id :requires requires :task task :evidence evidence)))

(shop3:defdomain (shop3-planning-domains-publication :noset t)
  ((:- (missing-requirement ?step)
       ((requires ?step ?fact) (not (observed ?fact))))
   (:- (earlier-ready-step ?step)
       ((precedes ?earlier ?step) (ready ?earlier)))
   (:- (ready ?step)
       ((publication-step ?step) (not (completed ?step))
        (not (missing-requirement ?step))))
   (:operator (!propose-publication-step ?step)
    () () ((planned-publication-step ?step)))
   (:method (publish-fedwiki-page) propose-next
    ((terminal-step ?last) (not (completed ?last))
     (ready ?step) (not (earlier-ready-step ?step)))
    ((!propose-publication-step ?step)))
   (:method (publish-fedwiki-page) verified-publication
    ((terminal-step ?last) (completed ?last))
    ())))

(defun publication-state (evidence completed profile source-origin)
  (when source-origin
    (check-type source-origin string)
    (unless (plusp (length (string-trim '(#\Space #\Tab #\Newline) source-origin)))
      (error "Supply the origin of the running source Wiki.")))
  (dolist (entry evidence)
    (destructuring-bind (fact reference) entry
      (unless (and (member fact *evidence-keys*) (stringp reference)
                   (plusp (length (string-trim '(#\Space #\Tab #\Newline) reference))))
        (error "Invalid publication observation ~S." entry))))
  (let* ((keys (mapcar #'first evidence))
         (stages (publication-stages profile source-origin))
         (mech (eq profile :mech-of-mastodon))
         (local-acceptance (if mech :local-browser-assets-verified :local-zip-discovery-verified))
         (terminal (if mech :verify-browser-preview :verify-publication)))
    (flet ((seen (fact) (member fact keys)))
      (when source-origin
        (when (and (or (seen :local-page-present) (seen :local-page-missing)
                       (member :resolve-local-site-root completed))
                   (not (seen :local-site-root-observed)))
          (error "Source page evidence requires the observed site root for ~A." source-origin))
        (when (and (member :observe-local completed)
                   (not (and (member :resolve-local-site-root completed)
                             (or (seen :local-page-present) (seen :local-page-missing)))))
          (error "Completing :OBSERVE-LOCAL requires the resolved source root and a persisted page observation.")))
      (when (or (and (seen :local-page-present) (seen :local-page-missing))
                (and (seen :target-ready) (seen :target-conflict))
                (and (seen :local-content-verified) (not (seen :local-page-present)))
                (and (seen local-acceptance)
                     (not (and (seen :local-page-present) (seen :local-attachment-verified))))
                (and (seen :release-reviewed)
                     (not (and (seen :local-content-verified) (seen local-acceptance))))
                (and (or (seen :target-ready) (seen :target-conflict))
                     (not (seen :release-reviewed)))
                (and (seen :public-assets-verified) (not (seen :target-ready)))
                (and (seen :public-page-verified) (not (seen :public-assets-verified)))
                (and mech
                     (or (and (seen :public-view-verified) (not (seen :public-page-verified)))
                         (and (seen :catalog-revision-verified) (not (seen :public-view-verified)))
                         (and (seen :public-browser-preview-verified)
                              (not (seen :catalog-revision-verified))))))
        (error "Conflicting or incomplete publication observations: ~S." keys))
      (when mech
        (dolist (pair '((:observe-local :local-page-present)
                        (:create-local :local-page-present)
                        (:fill-local :local-content-verified)
                        (:attach-local :local-attachment-verified)
                        (:verify-local-browser-assets :local-browser-assets-verified)
                        (:prepare-release :release-reviewed)
                        (:reconcile-target :target-ready)
                        (:publish-assets :public-assets-verified)
                        (:publish-page :public-page-verified)
                        (:verify-publication :public-view-verified)
                        (:observe-catalog-revision :catalog-revision-verified)
                        (:verify-browser-preview :public-browser-preview-verified)))
          (destructuring-bind (step fact) pair
            (when (and (member step completed)
                       (not (or (seen fact)
                                (and (eq step :observe-local) (seen :local-page-missing)))))
              (error "Completed step ~S requires observation ~S." step fact))))
        (when (and (member :observe-target completed)
                   (not (or (seen :target-ready) (seen :target-conflict))))
          (error "Target observation requires :TARGET-READY or :TARGET-CONFLICT."))))
    (dolist (step completed)
      (unless (assoc step stages)
        (error "Unknown publication step ~S for ~S." step profile)))
    (append
     (list (list 'terminal-step terminal))
     (when source-origin (list (list 'source-origin source-origin)))
     (loop for tail on stages
           for (step requires) = (first tail)
           append (cons (list 'publication-step step)
                        (append (loop for fact in requires collect (list 'requires step fact))
                                (loop for later in (rest tail)
                                      collect (list 'precedes step (first later))))))
     (loop for (fact reference) in evidence
           append (list (list 'observed fact) (list 'evidence-for fact reference)))
     (loop for step in completed collect (list 'completed step)))))

(defun plan-next (evidence &key completed (profile :shop3-planning-domains) source-origin)
  "Propose the next PROFILE step from EVIDENCE and COMPLETED.
Supply SOURCE-ORIGIN for a running Wiki. Omit it to replay archived snapshot plans.
Return the native plan-only result and its observed initial facts."
  (let* ((state (publication-state evidence completed profile source-origin))
         (domain (shop3:find-domain 'shop3-planning-domains-publication))
         (name (gensym "SHOP3-PUBLICATION-"))
         ;; The pinned SHOP3 attempts to strip a NIL tree for an empty
         ;; decomposition. Ask for plans and final states without that tree
         ;; only when the publication terminal step has been observed complete.
         (tree-p (not (member (second (assoc 'terminal-step state)) completed)))
         (shop3::*problem* shop3::*problem*))
    (unwind-protect
         (let ((problem (shop3:make-problem
                         (list name :domain 'shop3-planning-domains-publication :silently t)
                         (copy-tree state) '((publish-fedwiki-page)))))
           (multiple-value-bind (raw time trees states)
               (shop3:find-plans problem :domain domain :which :first :verbose 0
                                :plan-tree tree-p :collect-state t)
             (let ((initial-reader (find-symbol "INITIAL-FACTS-OF" "DREYECK/SHOP3")))
               (values
                (apply #'make-instance 'dreyeck/shop3:hyperdoc-htn-plan-result
                       :problem-name name :raw-plans raw
                       :plans (mapcar #'shop3:shorter-plan raw)
                       :plan-trees (if tree-p trees (mapcar (constantly nil) raw))
                       :final-states states
                       :time time :execution-mode :plan-only
                       (when (and initial-reader (fboundp initial-reader))
                         (list :initial-facts state)))
                state))))
      (let ((registered (shop3:find-problem name)))
        (when registered
          (shop3:delete-problem registered))))))
