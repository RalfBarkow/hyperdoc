;;;; Zettel 11667 — projektübergreifender Arbeitsplan, 12. November 2026.
;;;; In SLY zuerst (asdf:load-system "dreyeck/shop3"), dann diese Datei laden.
;;;; START-PLANS liefert je Spur ein natives HyperDoc-Planobjekt.
;;;; PLAN-LANES nimmt beobachtete, belegte Fakten entgegen (siehe unten).
;;;; Dieser Entwurf verwendet die Draft-Revisionen vom 14. November 2026.

(defpackage #:dreyeck/work/zettel-11667
  (:use #:cl)
  (:export #:plan-lane #:plan-lanes #:start-plans #:step-brief
           #:+topic-maps-candidate+ #:+hyperdoc-41+ #:+hyperdoc-42+))

(in-package #:dreyeck/work/zettel-11667)

(defparameter +topic-maps-candidate+ "c446a8228017f405c3a2650ca893e9450ac7cd7b")
(defparameter +hyperdoc-41+ "25f83196733a611810da2ea9596af1b4b2d215fb")
(defparameter +hyperdoc-42+ "36c69d3312ae70748ecd40a5452759fcfaad25c4")

(defparameter *lanes* '(:execution :review :operator))

;; Zeile: ID, Spur, benötigte Belege, konkreter Auftrag, erwarteter Beleg.
;; Die Reihenfolge macht START-PLANS lesbar; FIND-PLANS liefert alle Optionen.
(defparameter *steps*
  '((:v1-handoff :execution ()
     "Bestehende V1-Sitzung sichten. Laufstatus, bereits erzeugte Artefakte und Candidate-SHA festhalten."
     "Sitzungs- und Artefaktinventar mit Grenzen der bisherigen Reproduktion.")
    (:v1-assessment :execution (:v1-handoff :codex-available)
     "V1 in der bestehenden Sitzung fortsetzen. Reader-Checks und Abweichungen revisionsgebunden beurteilen."
     "V1-Assessment mit Revision, Umgebung, Reproduktion, offenen Fällen und Geltungsgrenzen.")
    (:review-41 :review ()
     "PR #41 unabhängig lesen. Claims, historische Inputs, Methodenvoraussetzungen und Testabdeckung prüfen."
     "Quellenassessment mit Gegenprobe, 195 dokumentierten Assertions und offenen Nachweisen.")
    (:reproduce-42 :execution
     (:v1-assessment :review-41 :v1-qualified :basis-41-accepted)
     "PR #42 isoliert mit qualifiziertem Candidate reproduzieren. Exporter, Snapshot und Alt-Pin-Refusal prüfen."
     "Report mit allen drei SHAs, Testausführung und Herkunft der exportierten Aussage.")
    (:decide-reader-profile :review (:reproduce-42)
     "Normative Prüfung, Testsuite und HyperDoc-Integration je für den begrenzten Reader-/Exporter-Pfad beurteilen."
     "Begründete Entscheidung mit Profil, Geltungsgrenzen und offenen Abnahmepunkten.")
    (:inspector-acceptance :operator
     (:decide-reader-profile :reader-profile-accepted :fresh-lisp-available)
     "Slice 22U und den PR-#42-Fall im frischen Lisp-Image lesen. Vom Ergebnis bis zu den Quellen navigieren."
     "Belegpfad mit Image, Revision, Inspector-Navigation und beobachteten Grenzen.")
    (:server-observation :operator ()
     "Operator erhebt den aktuellen Zustand von dreyeck.ch lesend."
     "Zeitgestempelter Ressourcen-, Service- und Build-Befund.")
    (:server-maintenance-assessment :operator
     (:server-observation :server-follow-up-selected)
     "Aus dem aktuellen Befund Handlungsbedarf für Ressourcen, Node.js und Build ableiten."
     "Begründete Betriebsentscheidung und Nachweise aus einer gegebenenfalls separat beauftragten Build-Prüfung.")
    (:zettelkasten-gui :operator (:java-environment)
     "Temurin/Java 25, lokalen GUI-Start und das Stabilitätsverhalten prüfen."
     "Dokumentierte Umgebung, GUI-Start, Verhalten und reproduzierbare Abweichungen.")
    (:ac-09 :operator (:zettelkasten-gui :java-environment)
     "Bei AC-09 ermitteln, ob der bestehende JUnit-Jupiter-Test entdeckt und tatsächlich ausgeführt wird."
     "Launcher-/Testreport mit Test-ID und Ausführungsstatus oder Beleg der Auslassung.")
    (:ac-11 :operator (:ac-09 :java-environment)
     "AC-11 auf der geklärten Testgrundlage ausführen und beurteilen."
     "Nachweis der Ausführung und Befund für AC-11.")
    (:a2-review :review (:a2-revision-available)
     "Lisp-Critic-A2 bei 2ad4d6bb unabhängig beurteilen. Gezielte Tests, Catalog FAIL und Source-Station BLOCKED einordnen."
     "Assessment mit Gegenbeispielen und Geltungsgrenzen von A2.")
    (:fedwiki-editor-review :operator (:fedwiki-staging-available)
     "Bestehenden Lese-/Editierpfad mit Originaleditor im Staging prüfen, einschliesslich Farm-Authentisierung."
     "Abnahme des beobachteten Pfads mit Authentisierungsbefund und Grenzen öffentlicher Integration.")
    (:annual-capacity :operator (:business-inputs)
     "Jahreskapazität und abrechenbare Zeit für Dreyeck GmbH bestimmen."
     "Nachvollziehbare Kapazitäts- und Preisannahmen.")
    (:pilot-offer :operator (:annual-capacity)
     "Erstes verkäufliches Angebot fachlich und preislich bestimmen."
     "Angebotsentwurf mit Leistung, Aufwand und Preis.")
    (:finalize-antipopulism :review (:article-draft-available)
     "Vorhandenen Beitrag redigieren und zur Veröffentlichungsreife bringen."
     "Redigierte Fassung mit nachvollziehbaren Entscheidungen.")))

(defparameter *availability-keys*
  '(:codex-available :fresh-lisp-available :server-follow-up-selected
    :java-environment :a2-revision-available :fedwiki-staging-available
    :business-inputs :article-draft-available))

(defparameter *required-revisions*
  (let ((integration (list +topic-maps-candidate+ +hyperdoc-41+ +hyperdoc-42+)))
    (list (list :v1-assessment +topic-maps-candidate+)
          (list :v1-qualified +topic-maps-candidate+)
          (list :review-41 +hyperdoc-41+)
          (list :a2-review "2ad4d6bb")
          (list :basis-41-accepted +hyperdoc-41+)
          (cons :reproduce-42 integration)
          (cons :decide-reader-profile integration)
          (cons :reader-profile-accepted integration)
          (cons :inspector-acceptance integration))))

(defun step-brief (step)
  (destructuring-bind (id lane requires task evidence)
      (or (assoc step *steps*) (error "Unknown step ~S." step))
    (list :step id :lane lane :requires requires
          :revisions (cdr (assoc id *required-revisions*))
          :task task :evidence evidence)))

(shop3:defdomain (zettel-11667 :noset t)
  ((:- (missing-requirement ?step)
       ((requires ?step ?requirement) (not (observed ?requirement))))
   (:- (unfinished-step ?lane)
       ((step-in-lane ?step ?lane) (not (completed ?step))))
   (:operator (!offer-next-step ?lane ?step)
     () () ((planned-next-step ?lane ?step)))
   (:method (next-step ?lane) ready-step
     ((step-in-lane ?step ?lane)
      (not (lane-active ?lane))
      (not (completed ?step))
      (not (blocked ?step))
      (not (missing-requirement ?step)))
     ((!offer-next-step ?lane ?step)))
   (:method (next-step ?lane) lane-complete
     ((not (lane-active ?lane)) (not (unfinished-step ?lane)))
     ())))

;; Beobachtungen werden vom Operator eingetragen; jeder Eintrag enthält
;; einen Beleg (z. B. URL, Pfad zum Report oder Referenz auf eine SLY-Ausgabe).
;; (:done <step> <beleg> [<revision> ...])
;; (:available <availability-key> <beleg>)
;; (:gate <gate> <beleg> <revision> ...)   Die exakten SHAs stehen in *REQUIRED-REVISIONS*.
;; (:active <step> <beleg>)               Maximal ein aktiver Schritt je Spur.
;; (:blocked <step> <beleg>)              Bewusster Aufschub / belegte Sperre.
;; Beim Abschluss ACTIVE entfernen und DONE mit Abschlussbeleg eintragen.
;; Ein GATE besagt, dass ein Mensch die Evidenz für den genannten Stand
;; akzeptiert hat; ein Assessment-Bericht allein öffnet kein GATE.

(defun observation-facts (observations)
  (let ((active-lanes nil)
        (seen-steps nil))
    (loop for entry in observations
          append
          (destructuring-bind (kind key evidence &rest revisions) entry
            (check-type evidence string)
            (when (zerop (length (string-trim '(#\Space #\Tab #\Newline) evidence)))
              (error "Missing evidence for ~S." key))
            (let ((expected (when (member kind '(:done :gate))
                              (cdr (assoc key *required-revisions*)))))
              (unless (equal revisions expected)
                (error "~S requires revisions ~S." key expected)))
            (when (member kind '(:done :active :blocked))
              (unless (assoc key *steps*)
                (error "Unknown step ~S." key))
              (when (member key seen-steps)
                (error "Multiple statuses for step ~S." key))
              (push key seen-steps))
            (cons (list* 'evidence-for kind key evidence revisions)
                  (ecase kind
                    (:done (list (list 'observed key) (list 'completed key)))
                    (:available
                     (unless (member key *availability-keys*)
                       (error "Unknown availability fact ~S." key))
                     (list (list 'observed key)))
                    (:gate
                     (unless (member key '(:v1-qualified :basis-41-accepted
                                           :reader-profile-accepted))
                       (error "Unknown gate ~S." key))
                     (list (list 'observed key)))
                    (:active
                     (let ((lane (second (assoc key *steps*))))
                       (when (member lane active-lanes)
                         (error "Multiple active steps in lane ~S." lane))
                       (push lane active-lanes)
                       (list (list 'lane-active lane))))
                    (:blocked (list (list 'blocked key)))))))))

(defun planning-state (observations)
  (append
   (loop for (step lane requirements) in *steps*
         collect (list 'step-in-lane step lane)
         append (loop for requirement in requirements
                      collect (list 'requires step requirement)))
   (observation-facts observations)))

(defun plan-lane (lane observations)
  "Return the native HyperDoc plan result and the initial state for a lane."
  (unless (member lane *lanes*)
    (error "Unknown lane ~S." lane))
  (let* ((state (planning-state observations))
         (domain (shop3:find-domain 'zettel-11667))
         (name (gensym "ZETTEL-11667-"))
         (initial-facts-option
           (let ((reader (find-symbol "INITIAL-FACTS-OF" "DREYECK/SHOP3")))
             (when (and reader (fboundp reader))
               (list :initial-facts state))))
         (problem nil)
         (shop3::*problem* shop3::*problem*))
    (unwind-protect
         (progn
           (setf problem
                 (shop3:make-problem (list name :domain 'zettel-11667 :silently t)
                                     (copy-tree state)
                                     (list (list 'next-step lane))))
           (multiple-value-bind (raw time trees states)
               (shop3:find-plans problem :domain domain :which :all
                                :verbose 0 :plan-tree t :collect-state t)
             (values
              (apply #'make-instance 'dreyeck/shop3:hyperdoc-htn-plan-result
                     :problem-name name
                     :raw-plans raw
                     :plans (mapcar #'shop3:shorter-plan raw)
                     :plan-trees trees
                     :final-states states
                     :time time
                     :execution-mode :plan-only
                     initial-facts-option)
              state)))
      (let ((registered (or problem (shop3:find-problem name))))
        (when registered
          (shop3:delete-problem registered))))))

(defun plan-lanes (observations)
  "Return an alist of lane keywords and native plan results."
  (loop for lane in *lanes*
        collect (cons lane (plan-lane lane observations))))

(defun start-plans ()
  "Plan from the note alone, with no live observations assumed."
  (plan-lanes nil))
