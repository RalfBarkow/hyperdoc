# Zettel 11667 · SHOP3-Domänen als editierbare Topics

Der Pilot enthält ein englisches Concept, die 16 Task-Topics aus der bereits in SLY ausgeführten Domäne und das Schema für ihre lokale Speicherung. Die Seed-Daten enthalten Quellen und Schrittbeschreibungen. Arbeitszustände werden als belegte Beobachtungen erfasst.

## Das Concept lesen und bearbeiten

| Datei | Rolle |
| --- | --- |
| `shop3-planning-domains.md` | Bearbeitbarer Markdown-Quelltext mit H1, Kurzbeschreibung und H2-Abschnitten. Als `format="mdita"` in DITA-OT einbindbar. |
| `shop3-planning-domains.html` | HTML5-Fassung für HDITA-Preview. Die Struktur folgt `article > h1, p, section…`. |
| `shop3-planning-domains.dita` | DITA-XML-Fassung mit `concept` und `conbody`. |
| `fedwiki-page.json` | FedWiki-Pilotseite mit einem editierbaren `markdown`-Story-Item und den beiden initialen Journalaktionen. |

Die Informationsrolle ist in allen Fassungen Concept. MDITA/HDITA verarbeiten den gezeigten Aufbau als generisches Lightweight-DITA-Topic. Die XML-Fassung verwendet die spezialisierte DITA-1.3-Struktur. Die stabile Arbeitsplan-ID `zettel-11667/shop3-planning-domains` ist von Dateiname, Wiki-Slug, Story-Item-ID und einem aus dem Titel abgeleiteten MDITA-Export-ID unabhängig. Für einen DITA-Export, der stabile Verweise braucht, wird die explizite ID der HDITA-/XML-Fassung verwendet oder beim Export zugeordnet. [OASIS Committee Note](https://docs.oasis-open.org/dita/LwDITA/v1.0/LwDITA-v1.0.html) · [DITA-OT Preview](https://www.dita-ot.org/dev/topics/lwdita-input.html) · [DITA Concept](https://dita-lang.org/1.3/dita/langref/containers/concept-elements)

### Im Originaleditor

1. In einer privaten, isolierten Wiki-Instanz eine neue Seite **Shop3 Planning Domains** erstellen (Slug `shop3-planning-domains`). Ein `markdown`-Item hinzufügen und den Text der Markdown-Datei unterhalb der ersten H1 einfügen. Die Wiki-Seite trägt den Seitentitel für den ASDF-Slug. Die mitgelieferten Concept-Dateien tragen die redaktionelle Frage als H1. Alternativ dient die JSON-Datei als Startfixture für den lokalen Seitenspeicher des Testservers unter einem freien Slug.
2. Das Story Item per Doppelklick im Originaleditor öffnen, einen Satz ändern und speichern. Danach die Seite neu laden und in ihrer gespeicherten JSON-Fassung die identische Item-ID, den neuen `item.text` und den zugehörigen `edit`-Journaleintrag prüfen.
3. Für einen Export aus dem Wiki die H1 aus `page.title` und den Body aus dem gespeicherten `item.text` bilden. Für die Frageform der mitgelieferten Concept-Fassung den dortigen redaktionellen Titel bei der Zuordnung explizit beibehalten. Die H-Ebenen im gerenderten Wiki-DOM sind Präsentation: Das Markdown-Plugin stellt sie als H3 dar. HDITA und DITA-XML werden aus der gewählten Markdown-Revision abgeleitet. Wenn der Pilot stattdessen HTML als Eingabesprache verwendet, ist der Inhalt des `article` für ein `html`-Item geeignet und die gespeicherte HTML-Quelle erhält diese Rolle für das Topic. Die beiden Eingabesprachen sollten nicht parallel dieselbe Revision überschreiben.

Die Probe knüpft an den bestehenden HyperDoc-Pfad „Original Wiki Editor Test“ an. Dort schreibt der Originalserver und HyperDoc liest zurück. Der bestehende Test belegt Paragraph-/Code-Items. Für Markdown gilt der Upstream-Editorvertrag, der konkrete Browser-Roundtrip dieser Seite bleibt zu prüfen. Der geprüfte HTML-Plugin-Quellstand lädt DOMPurify von einem CDN. Für eine offline gehaltene Installation müsste dieser Bezug lokal bereitgestellt werden, bevor der HTML-Pfad erprobt wird. [HyperDoc Original Editor](https://github.com/RalfBarkow/hyperdoc/blob/0e0190504c91ac8bace3ef770db04c7be81e6997/docs/fedwiki-original-editor-farm/README.md) · [Markdown-Plugin](https://github.com/fedwiki/wiki-plugin-markdown/blob/main/src/markdown.js) · [HTML-Plugin](https://github.com/fedwiki/wiki-plugin-html/blob/master/client/html.js)

## SQLite-Vertrag

| Tabelle oder View | Bedeutung |
| --- | --- |
| `topic` | Stabile Projekt-ID und Art des Topics. Bei Wiki-Zuordnung zusätzlich explizite Site, Slug und Story-Item-ID. |
| `topic_revision` | Quellrepräsentation in UTF-8, Zeitpunkt der Übernahme, Herkunft und SHA-256 der exakten Bytes. |
| `observation_event` | Belegter Schrittstatus, Gate-Entscheid oder beobachtete Verfügbarkeit. Ein Widerruf ist ein neues Ereignis. |
| `current_task_state` | Aktueller Zustand aller Task-Topics aus dem jüngsten Ereignis je Schlüssel. `unrecorded` bezeichnet fehlende Beobachtung. |
| `current_plan_observation` | Eingabe für einen Adapter zu den bereits verwendeten SLY-Beobachtungsformen. |

`schema.sql` und danach `seed.sql` einmal auf einer leeren, bereits mit SQLCipher geöffneten und geschlüsselten Verbindung ausführen. Die SQL-Dateien sind auch für eine flüchtige SQLite-In-Memory-Probe nutzbar. `PRAGMA foreign_keys = ON` pro Verbindung setzen. Das Schema verwendet die SQLite-JSON-Funktionen. [SQLite-Transaktionen](https://www.sqlite.org/lang_transaction.html) · [Fremdschlüssel](https://www.sqlite.org/foreignkeys.html)

Beim ersten Import ordnet der Adapter die Wiki-Koordinaten explizit zu. Er liest die gespeicherte Seite, sichert bei Bedarf ihre JSON-Quellbytes und speichert eine daraus abgeleitete Markdown-Revision mit Verweis auf Item und Quellrevision. Eine Wiederholung mit unveränderten Quellenbytes bleibt ohne neue Revision. Der Adapter prüft Änderungen gegen die zuletzt importierte Quellrevision. Die laufende Wiki-Instanz behält die Autorität über ihr Journal. Eine Änderung im Wiki und ihre spätere Übernahme in SQLite sind zwei beobachtbare Vorgänge.

Beispiel für die Abbildung eines belegten Abschlusses von `:review-41` und der anschliessenden Entscheidung. Die SQL-Ereignisse werden an der Anwendungsgrenze in dieselben bereits vorhandenen Formen übersetzt:

```lisp
(:done :review-41 "<Referenz auf das Assessment>" "25f83196733a611810da2ea9596af1b4b2d215fb")
(:gate :basis-41-accepted "<Referenz auf die Entscheidung>" "25f83196733a611810da2ea9596af1b4b2d215fb")
```

Der Adapter validiert die aus der DB gelesenen Schlüssel gegen die Domäne, bildet sie auf vorhandene Keywords ab und übergibt die Beobachtungsliste an `DREYECK/WORK/ZETTEL-11667:PLAN-LANES`. Er liest dafür keine Lisp-Formen aus dem Wiki-Text. Beim Schreiben prüft er die zugehörige Revision und die Belegung der Spur. Wiki-Revision und beobachteter Arbeitszustand haben eigene Zeitpunkte. Ein Edit oder ein simuliertes `planned-next-step` erzeugt keinen Abschluss. Einen Bezug zu Zettel 9124 kann später ein DMX-Export derselben stabilen IDs herstellen.

### Verschlüsselter Betrieb

- Die Anwendungsbindung öffnet die Datenbank mit SQLCipher und bezieht den Schlüssel lokal, beispielsweise aus dem macOS-Schlüsselbund. Vor produktiven Datenzugriffen prüft sie `PRAGMA cipher_version` und erzwingt das Lesen des Schemas. Die Gegenprobe verlangt, dass eine ungeschlüsselte Verbindung oder ein falscher Schlüssel das Schema nicht lesen kann. Als zusätzlicher Test eignet sich `PRAGMA cipher_integrity_check`.
- Der Schutzumfang muss auch die Wiki-Seitendateien und das Journal, Backups, Exportdateien sowie mögliche Browserkopien umfassen. Die Wiki-Site-Daten des Piloten gehören deshalb auf verschlüsselten lokalen Speicher oder in einen flüchtigen Testbereich. Für vertrauliche Topics ist die isolierte Site samt Browserprofil der Bearbeitungsort. Eine bewusst veröffentlichte Concept-Fassung kann als getrennte redaktionelle Kopie abgegeben werden.
- Die Lieferung enthält Schema und Seed, keinen laufenden Datenbankadapter. Das Schema wurde in SQLite im Speicher erprobt. Schlüsselbindung, Wiederöffnung und Originaleditor-Roundtrip sind Abnahmepunkte auf dem Zielsystem. [SQLCipher API](https://www.zetetic.net/sqlcipher/sqlcipher-api/index.html) · [SQLCipher Design](https://www.zetetic.net/sqlcipher/design/)

## Eine vorhandene SHOP3-Domäne in SLY lesen

Im aktuellen HyperDoc-Checkout nach Prüfung des ASDF-Systems:

```lisp
(asdf:load-system "dreyeck/work/remote-control-planning")
```

```lisp
(loop for case in '(:c :d)
      collect
      (list case
            (length
             (dreyeck/shop3:raw-plans-of
              (dreyeck/work/remote-control-planning:remote-control-plan case)))))
```

Der Repository-Test erwartet `((:C 2) (:D 0))`. Fall C enthält beide möglichen Routen. In Fall D fehlt der Autorisierungsfakt. Die Übergangsoperatoren modellieren Auswirkungen im SHOP3-Zustand. [Lisp-Quelle](https://github.com/RalfBarkow/hyperdoc/blob/0e0190504c91ac8bace3ef770db04c7be81e6997/dreyeck/work/remote-control-planning.lisp)
