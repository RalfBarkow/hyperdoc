# What Is a SHOP3 Planning Domain?

A SHOP3 planning domain describes how tasks can be broken down and which primitive steps are applicable. A planning problem supplies an initial state and tasks to plan for. A plan is a proposed sequence of steps for that particular state.

## Methods and operators

A method reduces a compound task to subtasks when its preconditions hold. An operator models a primitive step and its effects on the planning state. The same compound task can have several applicable methods. For example, an investigation can prepare a comparison of two CXTM serializations, a question about the applicable CTM edition, or both.

## Examples to read

- [Blocks World](https://github.com/shop-planner/shop3/blob/ce53f9b651acde8c44dc21eddb1a1c5b97f10536/shop3/examples/blocks/block2.lisp) shows how picking up or stacking a block changes the facts that make the next move possible.

- [Logistics](https://github.com/shop-planner/shop3/blob/ce53f9b651acde8c44dc21eddb1a1c5b97f10536/shop3/examples/logistic/logistic.lisp) uses location facts to choose between delivery within one city and transport via airports.

- [Zettelkasten Mobile Control](https://github.com/RalfBarkow/hyperdoc/blob/0e0190504c91ac8bace3ef770db04c7be81e6997/dreyeck/work/remote-control-planning.lisp) shows two alternative methods for a single task. Case C supplies facts for both routes. Case D omits the authorization fact and yields no plan.

- [Topic Maps Conformance Investigation](https://github.com/RalfBarkow/hyperdoc/blob/25f83196733a611810da2ea9596af1b4b2d215fb/dreyeck/work/topic-maps-conformance-planning.lisp) plans inquiries from retained evidence. The original case status, a later reader observation, and a successful control remain individually inspectable.

## The work plan in Zettel 11667

In Zettel 11667, the domain proposes the next step for each workstream. The work topic for reviewing PR #41 can be read before its review begins. Once the assessment exists, a dated observation can record its completion and cite the reviewed revision. Acceptance of that revision as an integration basis is a separate observation.

These observations become initial facts in a subsequent planning problem. The plan can then propose another step when its prerequisites are present. A proposed step is marked in the simulated final state. Completion is recorded from the evidence of the work performed.

## Reading a plan result

Read the initial facts, the selected method in the native plan tree, and the final state together. In the Zettel 11667 domain, an empty successful plan means the workstream has no unfinished steps. A search with no plan means no method applies to the current state.
