# Localhost-first publication

The working page is **Shop3 Planning Domains**, slug
`shop3-planning-domains`. The ZIP, its primary ASD filename and its
primary ASDF system use the same plural name.

## Plan from the running local Wiki

Use `:source-origin "http://localhost:3000"` with either publication
profile. First SHOP3 proposes `:resolve-local-site-root`. Record the
effective source root and backend from the running Wiki configuration as
`:local-site-root-observed`. After this step SHOP3 proposes `:observe-local`.
Confirm the slug through its JSON endpoint and its persisted store.
A browser lineup observation can be recorded independently as
`:local-lineup-page-visible` or `:local-lineup-not-found`.

On 15 November 2026, the user reported that
`/view/welcome-visitors/view/shop3-planning-domains` was the working lineup.
The same lineup with `mech-of-mastodon` displayed "We could not find this page"
and "create new blank page". Both observations belong to the local origin.
The effective store and the two JSON responses still require observation.

```lisp
(shop3-planning-domains/publication:plan-next
 '((:local-lineup-not-found
    "2026-11-15, user observation at http://localhost:3000/view/welcome-visitors/view/mech-of-mastodon"))
 :profile :mech-of-mastodon
 :source-origin "http://localhost:3000")
```

See the DITA concept **FedWiki site root** and the associated operational
tasks in the Zettel 11687 Task Network. Calls without `:source-origin`
continue to support replay of the earlier snapshot plans.

## Observe and complete the local page

Read `http://localhost:3000/shop3-planning-domains.json` from the
workstation. Check HTTP status, title, story and journal. The lineup URL
is a view address. To name the source bytes, also observe the persisted
page with `DREYECK/LOCAL-FEDWIKI-PAGE:OBSERVE-LOCAL-FEDWIKI-PAGE-SOURCE`,
supplying the site root from the running local Wiki configuration.
Check whether an apparent page exists only in the browser before deciding
that the server page is missing.

A read-only check from the workstation in SLY:

```lisp
(asdf:load-system "dreyeck/local-fedwiki-page")
```

```lisp
(multiple-value-bind (body status)
    (drakma:http-request
     "http://localhost:3000/shop3-planning-domains.json"
     :method :get :redirect nil :force-binary t)
  (list :http-status status
        :page
        (when (eql status 200)
          (let ((page (shasht:read-json
                       (sb-ext:octets-to-string body :external-format :utf-8))))
            (list :title (gethash "title" page)
                  :items (map 'list
                              (lambda (item)
                                (list (gethash "id" item)
                                      (gethash "type" item)))
                              (gethash "story" page))
                  :journal-actions (map 'list
                                        (lambda (action) (gethash "type" action))
                                        (gethash "journal" page)))))))
```

The local original editor can add the Markdown body from
`shop3-planning-domains.md` and one Assets item with text
`pages/shop3-planning-domains`. Compare with `data/fedwiki-page.json`
as a fixture. Preserve existing item IDs and journal entries. Attach
the reviewed ZIP, verify its SHA-256 after downloading it locally, and
reread the page and the attachment. The ZIP contains the other reading
pages, Lisp and SQLite seed. The local work database and private
observations remain with the local author.

The repository already provides
`DREYECK/FEDWIKI-PAGE-MATERIALIZATION:MATERIALIZE-FEDWIKI-PAGE-JSON`
for writing a prepared Page JSON to a local file store. It rejects an
existing target in its default path check. Use it for a new isolated
file-store fixture. For a missing page on a running Wiki, its native
server `create` Action supplies the server-side existence check and
index updates. The Lisp
`DREYECK/FEDWIKI-PAGE-AUTHORING:EDIT-FEDWIKI-PAGE-ITEM` path covers
ordinary edits of an existing item. For adding items on the live page
use the native Wiki `add` action through the original editor.

## Plan the next step in SLY

Arbeite in der [DITA-Map von Zettel 11687](https://chatgpt.com/library?file_id=libfile_d3ade7d14194819182432f7cdbdea992&account_id=personal)
zuerst **Ein ZIP-Archiv in SLY entpacken** ab. Das Ergebnis
`*publication-unpack*` enthält den beobachteten ASD-Pfad für **Den
Publikationsplan in SLY laden**.

```lisp
(let* ((asd (truename (getf *publication-unpack* :asd)))
       (name "shop3-planning-domains/publication"))
  (asdf:load-asd asd)
  (let* ((system (or (asdf:find-system name nil)
                     (error "~A ist nach dem Laden von ~A nicht registriert."
                            name asd)))
         (source (asdf:system-source-file system)))
    (unless (and source (equal asd (truename source)))
      (error "ASDF verwendet ~A. Erwartete ASD: ~A" source asd))
    (asdf:load-system name)
    (list :system name :asd source)))
```

```lisp
(defparameter *shop3-publication-plan*
  (shop3-planning-domains/publication:plan-next nil))

(dreyeck/shop3:plans-of *shop3-publication-plan*)
```

Expected first step for this archived replay: `:observe-local`. After observing a stored page,
replace the sample reference with its observed URL and SHA-256:

```lisp
(shop3-planning-domains/publication:plan-next
 '((:local-page-present "local page source and SHA-256"))
 :completed '(:observe-local))
```

Expected next step: `:fill-local`. A confirmed missing page instead
permits `:create-local`. Mark steps completed only after readback.
If an existing item or ZIP already matches the intended release, record
the observation and mark the corresponding step complete.

## Verify ZIP discovery

After the local ZIP has been attached and its identity observed, the
planner proposes `:verify-zip-discovery`, the existing acceptance task
from Zettel 11687. Record `:local-zip-discovery-verified` only after
the Catalog reports the exact member
`shop3-planning-domains/shop3-planning-domains.asd` and its offer from
the page asset. Opening and inspecting the offer precede any decision
to materialize the selected package for registration. The reference
fixtures and task topics are in the updated Zettel 11687 Task Network.

A runtime with loose-ASD-only discovery leaves this ZIP acceptance open.
In that runtime the attachment is available for download. Its recognition
as an ASD source is still open.

## Prepare and publish the release

1. Review a release snapshot of the local page and the asset manifest.
   The public journal should contain only publishable actions. If the
   local journal contains private material, make a public copy from
   the reviewed story and record the provenance of that copy outside
   the private journal. Keep the original local journal intact.
2. Observe the actual production Wiki origin and site store, and check
   for an existing page or asset with the same identity. An existing
   matching file can be accepted by digest. A different existing
   revision calls for reconciliation before any update.
3. Publish the reviewed assets, verify them on the destination, then
   publish the reviewed page and read it back. The operator writes using
   the authenticated Wiki origin or the already established deployment
   for that site's pages and assets checkouts.
   `DREYECK/FEDWIKI-PUBLICATION:MAKE-LOCAL-FEDWIKI-REPOSITORY-CHECKOUT`
   resolves the two local publication inputs. Git push and production
   installation are separate operations.
4. Check the production Wiki JSON, ZIP digest and
   `https://dreyeck.ch/view/shop3-planning-domains`. Record the ZIP candidate
   and Workspace offer through the same discovery contract as on localhost.

A server receiving a bare localhost URL would address its own
loopback. Transfer the reviewed bytes or the corresponding Git
revision. The repository also documents a cross-origin FedWiki fork
with an embedded page snapshot in a controlled fixture. That is a
distinct route with its own browser and authentication conditions.

Sources: [Local materialization](https://github.com/RalfBarkow/hyperdoc/blob/0e0190504c91ac8bace3ef770db04c7be81e6997/dreyeck/src/fedwiki-page-materialization.lisp),
[local item authoring](https://github.com/RalfBarkow/hyperdoc/blob/0e0190504c91ac8bace3ef770db04c7be81e6997/dreyeck/src/fedwiki-page-authoring.lisp),
[publication inputs](https://github.com/RalfBarkow/hyperdoc/blob/0e0190504c91ac8bace3ef770db04c7be81e6997/dreyeck/src/fedwiki-publication.lisp),
[cross-origin fork reading](https://github.com/RalfBarkow/hyperdoc/blob/0e0190504c91ac8bace3ef770db04c7be81e6997/dreyeck/pages/fedwiki-config/Forking%20a%20Local%20Page%20Across%20Origins.html).


## Mech of Mastodon auf dreyeck.ch publizieren

Die Aufgabe `publish-fedwiki-page` verwendet dieselbe Publikationsdomäne.
Das Profil `:mech-of-mastodon` hält die beiden geprüften Quellbytes zusammen,
FedWiki-JSON und den ZIP-Anhang. Die DITA-Anleitung und die CTM-Relationen
liegen im [Task Network aus Zettel 11687](https://chatgpt.com/library?file_id=libfile_d3ade7d14194819182432f7cdbdea992&account_id=personal).

Führe zuerst den geprüften ASD-Ladeblock unter **Plan the next step in SLY** aus.

```lisp
(defparameter *mech-publication-plan*
  (shop3-planning-domains/publication:plan-next
   nil :profile :mech-of-mastodon))

(clog-moldable-inspector:clog-inspect :object *mech-publication-plan*)
```

Für den archivierten Snapshot ist der erste Vorschlag `:observe-local`. `plan-next` nimmt eine Liste aus
`(Fakt "Belegreferenz")` sowie `:completed` entgegen. Verwende pro Lauf die
bisherigen Belege desselben Releases. Bereits passende Dateien können nach
Readback als erledigter Schritt belegt werden. Ein Konfliktbefund öffnet
`:reconcile-target`. Sobald die Klärung dokumentiert ist, ersetze
`:target-conflict` durch `:target-ready` mit der neuen Belegreferenz.

| Schritt | Beleg |
| --- | --- |
| `:observe-local`, ggf. `:create-local`, `:fill-local` | Lokaler Root, Seitendatei, Story und publizierbares Journal |
| `:attach-local`, `:verify-local-browser-assets` | ZIP-SHA-256, ASD-Eintragsname und lokaler Klickpfad |
| `:prepare-release` | Manifest mit den beiden Release-Hashes |
| `:observe-target`, ggf. `:reconcile-target` | Tatsächlicher Catalog-Store und Serverbefund zu beiden Zielen |
| `:publish-assets` | Gestagtes ZIP am endgültigen Pfad zurückgelesen |
| `:publish-page` | Gestagtes JSON unter `pages/mech-of-mastodon` zurückgelesen |
| `:verify-publication` | Öffentliche Story mit den erwarteten Items |
| `:observe-catalog-revision` | Laufender Stand enthält `96e19220` und liefert die erwartete Host-Datei |
| `:verify-browser-preview` | ▶ startet den Live-Abruf und zeigt Mech Preview im Story-Pane |

Die Browser-Auslieferung aus dem ZIP und das ZIP-basierte Workspace-Angebot
haben verschiedene Abnahmekriterien. Für Shop3 Planning Domains verwendet
das Standardprofil weiterhin `:verify-zip-discovery` mit Workspace-Angebot.
Für Mech dokumentiert `:verify-local-browser-assets` den Browserpfad aus
PR #49. Nach dem letzten bestätigten Schritt liefert SHOP3 einen erfolgreichen
leeren Plan. Die Planung führt die dokumentierten Serveroperationen nicht aus.

```lisp
(asdf:test-system "shop3-planning-domains/publication")
```
