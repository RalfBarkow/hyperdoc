-- Open and key the connection with SQLCipher before applying this schema.
-- The SQL itself is also usable on an in-memory SQLite fixture.
PRAGMA foreign_keys = ON;
BEGIN;

CREATE TABLE topic (
  topic_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('concept', 'task')),
  title TEXT NOT NULL,
  lane TEXT,
  wiki_origin TEXT,
  wiki_slug TEXT,
  wiki_item_id TEXT,
  UNIQUE (wiki_origin, wiki_slug, wiki_item_id),
  CHECK (
    (kind = 'concept' AND lane IS NULL) OR
    (kind = 'task' AND lane IS NOT NULL AND
     lane IN ('execution', 'review', 'operator'))
  ),
  CHECK (
    (wiki_origin IS NULL AND wiki_slug IS NULL AND wiki_item_id IS NULL) OR
    (wiki_origin IS NOT NULL AND wiki_slug IS NOT NULL AND wiki_item_id IS NOT NULL)
  )
);

CREATE TABLE topic_revision (
  revision_id INTEGER PRIMARY KEY,
  topic_id TEXT NOT NULL REFERENCES topic (topic_id),
  recorded_at TEXT NOT NULL,
  source_format TEXT NOT NULL
    CHECK (source_format IN ('markdown', 'hdita', 'dita', 'fedwiki-json')),
  source_ref TEXT NOT NULL,
  source_octets BLOB NOT NULL,
  source_sha256 TEXT NOT NULL
    CHECK (length(source_sha256) = 64 AND source_sha256 NOT GLOB '*[^0-9a-f]*')
);

CREATE VIEW current_topic_revision AS
SELECT revision.*
FROM topic_revision AS revision
JOIN (
  SELECT topic_id, max(revision_id) AS revision_id
  FROM topic_revision GROUP BY topic_id
) AS latest USING (topic_id, revision_id);

-- Observation subjects use the existing plan keys, spelled without a colon.
-- The application checks key/revision pairs against the loaded planning domain.
CREATE TABLE observation_event (
  event_id INTEGER PRIMARY KEY,
  scope TEXT NOT NULL CHECK (scope IN ('step', 'gate', 'availability')),
  plan_key TEXT NOT NULL CHECK (length(trim(plan_key)) > 0),
  topic_id TEXT REFERENCES topic (topic_id),
  recorded_at TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('active','done','blocked','gate','available','withdrawn')),
  evidence_ref TEXT NOT NULL CHECK (length(trim(evidence_ref)) > 0),
  revisions_json TEXT NOT NULL DEFAULT '[]'
    CHECK (json_valid(revisions_json) AND json_type(revisions_json) = 'array'),
  CHECK (
    (scope = 'step' AND topic_id IS NOT NULL
     AND topic_id = 'zettel-11667/' || plan_key
     AND kind IN ('active','done','blocked','withdrawn')) OR
    (scope = 'gate' AND topic_id IS NULL AND kind IN ('gate','withdrawn')) OR
    (scope = 'availability' AND topic_id IS NULL AND kind IN ('available','withdrawn'))
  )
);

CREATE INDEX observation_lookup ON observation_event (scope, plan_key, event_id);

CREATE VIEW current_plan_observation AS
SELECT event.*
FROM observation_event AS event
JOIN (
  SELECT scope, plan_key, max(event_id) AS event_id
  FROM observation_event GROUP BY scope, plan_key
) AS latest USING (scope, plan_key, event_id)
WHERE event.kind <> 'withdrawn';

CREATE VIEW current_task_state AS
SELECT topic.topic_id, topic.title, topic.lane,
       coalesce(event.kind, 'unrecorded') AS status,
       event.recorded_at, event.evidence_ref, event.revisions_json
FROM topic
LEFT JOIN current_plan_observation AS event ON event.topic_id = topic.topic_id
WHERE topic.kind = 'task';

PRAGMA user_version = 1;
COMMIT;
