# SHOP3 Planning Domains · Zettel 11667

The page slug and primary ASDF system are both `shop3-planning-domains`.
The archive carries the SHOP3 domain already exercised in SLY, 16 work
topics, the PR #41 source review and the Concept in Markdown, HTML5/HDITA
and DITA XML. The SQL seed contains the topics and their first source
revisions. Work status is recorded separately when an observation exists.

For the existing localhost page, start with the [publication plan](topics/localhost-first-publication.md). It keeps the same slug across localhost and dreyeck.ch. The optional ASDF system `shop3-planning-domains/publication` proposes the next step. The Task Network documents ZIP extraction followed by explicit ASD registration from the materialization result.

The next publication step after a verified local attachment is
`:verify-zip-discovery` from the Zettel 11687 Task Network. The released
ZIP is discovered through the FedWiki Assets item. A successful ZIP
acceptance is required before preparing the public release.

## Attach to a FedWiki page

1. In the original Wiki, create a page titled **Shop3 Planning Domains**
   (slug `shop3-planning-domains`). Use the existing page if that slug is
   taken. Paste the body below the H1 of `topics/shop3-planning-domains.md`
   into a Markdown item. The JSON at `data/fedwiki-page.json` is a complete
   fixture for a fresh test store.
2. Add a FedWiki **Assets** item. Set its text to
   `pages/shop3-planning-domains` and save. From the Wiki origin associated
   with this site, use the Assets item's upload control as the site's owner
   to upload `shop3-planning-domains.zip`. The file is then available on
   that origin at `/assets/pages/shop3-planning-domains/shop3-planning-domains.zip`.
3. Open `https://dreyeck.ch/view/shop3-planning-domains` when the Catalog's
   local store is the one holding the page. The documented setting is
   `HYPERDOC_FEDWIKI_SITE_ROOT=/home/rgb/.wiki/dreyeck.ch/`. Check the
   running setting before copying files on the server.

The reviewed HyperDoc revision `0e0190504c91ac8bace3ef770db04c7be81e6997`
scans the referenced directory for immediate `.asd` files. The updated
publication plan requires the Catalog to discover the ZIP as a page
attachment. Use the Zettel 11687 acceptance task before publishing.
The older loose-file path remains available for other page attachments.

Sources: [FedWiki asset discovery](https://github.com/RalfBarkow/hyperdoc/blob/0e0190504c91ac8bace3ef770db04c7be81e6997/dreyeck/src/fedwiki-assets.lisp),
[Catalog offer](https://github.com/RalfBarkow/hyperdoc/blob/0e0190504c91ac8bace3ef770db04c7be81e6997/dreyeck/src/local-fedwiki-view.lisp),
[workspace execution policy](https://github.com/RalfBarkow/hyperdoc/blob/0e0190504c91ac8bace3ef770db04c7be81e6997/dreyeck/src/page-attached-workspace-reconstruction.lisp).

## Test an already materialized copy in a trusted SLY image

Use the observed ASD path from the materialization task. The path below
shows an example for a copy already observed at that location. Evaluate
the blocks in order with the HyperDoc checkout known to ASDF.

```lisp
(asdf:load-asd
 (merge-pathnames "Downloads/shop3-planning-domains/shop3-planning-domains.asd"
                  (user-homedir-pathname)))
```

```lisp
(asdf:test-system "shop3-planning-domains")
```

Expected marker: `SHOP3-PLANNING-DOMAINS-PASS`. The tests cover the three
observed starting proposals and a fixture in which PR #42 becomes ready
when V1 qualification is added to the other required observations.

```lisp
(asdf:load-system "shop3-planning-domains/presentation")
```

```lisp
(defparameter *planning-domains-book*
  (hyperbook:find-hyperbook "shop3-planning-domains" :signal-error? t))

(defparameter *planning-domains-start*
  (dreyeck/work/zettel-11667:start-plans))

(clog-moldable-inspector:clog-inspect
 :object (cdr (assoc :review *planning-domains-start*)))
```

## Observe the existing discovery operation in the local Wiki store

Evaluate the following before registering an extracted copy. This checks
the real page-to-asset relationship rather than just the download.

```lisp
(asdf:load-system "dreyeck/fedwiki-assets")
```

```lisp
(dreyeck/fedwiki-assets:page-attached-asdf-discovery-observation
 (dreyeck/fedwiki-assets:configured-local-site-root)
 "shop3-planning-domains")
```

The ZIP-only layout yields an empty `:ASDF-FILES` under the reviewed
implementation. For ZIP acceptance record the archive candidate and the
Workspace offer from the updated runtime.
Inside the ZIP the ASD is at
`shop3-planning-domains/shop3-planning-domains.asd`.

The storage and editor details are in
`topics/topic-authoring-and-storage.md`. The SQLite adapter and the
encrypted editor roundtrip are open. The attached Lisp planning domain
consumes the existing observation forms through `PLAN-LANES`.


Für die Publikation von Mech of Mastodon unterstützt
`shop3-planning-domains/publication:plan-next` das Profil
`:mech-of-mastodon`. Die Belege und den SLY-Einstieg beschreibt
[Localhost-first publication](topics/localhost-first-publication.md).
